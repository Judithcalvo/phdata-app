"""
Source registry. Add new sources by writing a module in sources/ and
registering it here. Each source exposes:
    label, description, provider, url, render_filters(), fetch(**params)
"""
from sources import cdc_brfss, samhsa_nssats, cdc_places

REGISTRY = {
    "cdc_brfss": {
        "label": "CDC BRFSS — Behavioral Risk Factor Surveillance",
        "description": "Adult risk-behavior + chronic condition survey, state-level.",
        "provider": "CDC (Socrata)",
        "url": "https://chronicdata.cdc.gov",
        "render_filters": cdc_brfss.render_filters,
        "fetch": cdc_brfss.fetch,
    },
    "cdc_places": {
        "label": "CDC PLACES — Local-area mental & behavioral health",
        "description": "Census-tract estimates: mental distress, depression, sleep, etc.",
        "provider": "CDC (Socrata)",
        "url": "https://www.cdc.gov/places",
        "render_filters": cdc_places.render_filters,
        "fetch": cdc_places.fetch,
    },
    "samhsa_nssats": {
        "label": "SAMHSA N-SSATS — Substance use treatment facilities",
        "description": "National Survey of Substance Abuse Treatment Services locator data.",
        "provider": "SAMHSA",
        "url": "https://findtreatment.samhsa.gov",
        "render_filters": samhsa_nssats.render_filters,
        "fetch": samhsa_nssats.fetch,
    },
}
