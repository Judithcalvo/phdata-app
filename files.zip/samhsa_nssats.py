"""
SAMHSA — substance use & mental health treatment facility locator.
Uses the findtreatment.gov public API.
Docs: https://findtreatment.gov/locator/exportsAsJson
"""
import requests
import pandas as pd
import streamlit as st

ENDPOINT = "https://findtreatment.gov/locator/exportsAsJson/v2"


def render_filters() -> dict:
    c1, c2, c3 = st.columns(3)
    state = c1.text_input("State (e.g. TX)", value="TX")
    service_type = c2.selectbox(
        "Service type",
        ["SA", "MH", "BHA"],
        format_func=lambda s: {"SA": "Substance Abuse", "MH": "Mental Health", "BHA": "Both"}[s],
    )
    page_limit = c3.number_input("Pages to fetch (250/page)", 1, 20, 2)
    return {"state": state.strip().upper(), "service_type": service_type, "pages": int(page_limit)}


def fetch(state: str, service_type: str, pages: int) -> pd.DataFrame:
    all_rows = []
    for page in range(1, pages + 1):
        params = {"sType": service_type, "sCodes": "1", "limitType": 2, "pageSize": 250, "page": page}
        if state:
            params["sAddr"] = state
        r = requests.get(ENDPOINT, params=params, timeout=60)
        r.raise_for_status()
        data = r.json()
        rows = data.get("rows", data if isinstance(data, list) else [])
        if not rows:
            break
        all_rows.extend(rows)
    if not all_rows:
        return pd.DataFrame()
    df = pd.json_normalize(all_rows)
    # Keep useful columns; drop nested junk
    keep = [c for c in df.columns if not c.startswith("_")]
    return df[keep]
